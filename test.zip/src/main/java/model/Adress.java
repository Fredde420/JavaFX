package model;

public class Adress {
    private int adressNr;
    private String adressRad1;
    private String adressRad2;
    private String postNr;
    private String ort;
    private int userID;

    public int getAdressNr() { return adressNr; }
    public void setAdressNr(int adressNr) { this.adressNr = adressNr; }

    public String getAdressRad1() { return adressRad1; }
    public void setAdressRad1(String adressRad1) { this.adressRad1 = adressRad1; }

    public String getAdressRad2() { return adressRad2; }
    public void setAdressRad2(String adressRad2) { this.adressRad2 = adressRad2; }

    public String getPostNr() { return postNr; }
    public void setPostNr(String postNr) { this.postNr = postNr; }

    public String getOrt() { return ort; }
    public void setOrt(String ort) { this.ort = ort; }

    public int getUserID() { return userID; }
    public void setUserID(int userID) { this.userID = userID; }
}
